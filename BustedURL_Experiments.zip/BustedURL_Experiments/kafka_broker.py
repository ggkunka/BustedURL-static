#kafka_broker.py

from kafka import KafkaProducer
import json

def send_message(topic, message):
    producer = KafkaProducer(bootstrap_servers='localhost:9092',
                             value_serializer=lambda v: json.dumps(v).encode('utf-8'))
    producer.send(topic, message)
    producer.flush()

def receive_message(consumer):
    for message in consumer:
        print(f"Received message: {message.value}")
