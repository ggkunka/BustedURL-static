#tests/test_baseline.py

import time
from src.main import process_chunk

def test_baseline():
    start_time = time.time()
    print("Running baseline test...")

    model = EnsembleModel()
    dataset_path = 'data/cleaned_urls.csv'
    
    results_queue = []
    for chunk in load_data_incrementally(dataset_path, chunk_size=100):
        process_chunk(model, chunk, results_queue)
    
    end_time = time.time()
    print(f"Baseline test completed. Total time: {end_time - start_time} seconds")

if __name__ == "__main__":
    test_baseline()
