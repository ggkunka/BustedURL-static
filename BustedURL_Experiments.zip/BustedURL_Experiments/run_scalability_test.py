#run_scalability_test.py

import subprocess

def run_tests():
    print("Running Baseline Test (No Kafka, No Celery)...")
    subprocess.run(["python3.12", "tests/test_baseline.py"])

    print("Running Scalability Test (With Kafka and Celery)...")
    subprocess.run(["python3.12", "src/main.py"])

if __name__ == "__main__":
    run_tests()
