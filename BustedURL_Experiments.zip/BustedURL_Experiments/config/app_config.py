#config/app_config.py

# Configuration file for various settings

CONFIG = {
    "disable_xlnet": True  # Set to True to disable XLNet in the ensemble
}
