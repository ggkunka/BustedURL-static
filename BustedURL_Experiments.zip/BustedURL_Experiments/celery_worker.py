#celery_worker.py

from celery import Celery
from src.ensemble_model import EnsembleModel
from src.utils.model_helper import process_chunk

app = Celery('tasks', broker='pyamqp://guest@localhost//')

@app.task
def run_ensemble(chunk):
    model = EnsembleModel()
    return process_chunk(model, chunk)
