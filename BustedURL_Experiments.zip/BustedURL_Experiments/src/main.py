#src/main.py

import multiprocessing as mp
from src.ensemble_model import EnsembleModel
from src.utils.model_helper import load_data_incrementally
from kafka_broker import send_message
from celery_worker import run_ensemble
import time

def process_chunk_kafka(model, chunk, results_queue):
    """
    Processes a chunk using Kafka and Celery.
    """
    for _, row in chunk.iterrows():
        url = row['url']
        label = row['label']  # 1 for malicious, 0 for benign
        features = model.extract_features(url)
        prediction = model.classify(features)

        # Send prediction via Kafka
        send_message('predictions', {'url': url, 'prediction': prediction, 'label': label})

    results_queue.put(prediction)

def main():
    model = EnsembleModel()
    dataset_path = 'data/cleaned_urls.csv'

    # Create multiprocessing queues
    results_queue = mp.Queue()

    # Define number of CPUs (24 cores)
    num_cpus = 24
    pool = mp.Pool(processes=num_cpus)

    start_time = time.time()

    # Read data incrementally and process with Kafka/Celery in parallel
    for chunk in load_data_incrementally(dataset_path, chunk_size=100):
        pool.apply_async(run_ensemble.delay(chunk))

    # Close the pool and wait for all tasks to complete
    pool.close()
    pool.join()

    end_time = time.time()
    print(f"Processing time with Kafka and Celery: {end_time - start_time} seconds")

if __name__ == "__main__":
    main()
