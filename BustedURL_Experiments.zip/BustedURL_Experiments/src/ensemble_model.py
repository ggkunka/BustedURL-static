#src/ensemble_model.py

import torch
from transformers import BertTokenizer, BertModel, RobertaTokenizer, RobertaModel, DistilBertTokenizer, DistilBertModel
from config.app_config import CONFIG

class EnsembleModel:
    def __init__(self):
        self.bert_tokenizer = BertTokenizer.from_pretrained('bert-base-uncased')
        self.bert_model = BertModel.from_pretrained('bert-base-uncased')

        self.roberta_tokenizer = RobertaTokenizer.from_pretrained('roberta-base')
        self.roberta_model = RobertaModel.from_pretrained('roberta-base')

        self.distilbert_tokenizer = DistilBertTokenizer.from_pretrained('distilbert-base-uncased')
        self.distilbert_model = DistilBertModel.from_pretrained('distilbert-base-uncased')

        if not CONFIG['disable_xlnet']:
            from transformers import XLNetTokenizer, XLNetModel
            self.xlnet_tokenizer = XLNetTokenizer.from_pretrained('xlnet-base-cased')
            self.xlnet_model = XLNetModel.from_pretrained('xlnet-base-cased')
        else:
            self.xlnet_model = None

    def extract_features(self, url):
        inputs = self.bert_tokenizer(url, return_tensors="pt")
        bert_output = self.bert_model(**inputs).last_hidden_state

        inputs = self.roberta_tokenizer(url, return_tensors="pt")
        roberta_output = self.roberta_model(**inputs).last_hidden_state

        inputs = self.distilbert_tokenizer(url, return_tensors="pt")
        distilbert_output = self.distilbert_model(**inputs).last_hidden_state

        if self.xlnet_model:
            inputs = self.xlnet_tokenizer(url, return_tensors="pt")
            xlnet_output = self.xlnet_model(**inputs).last_hidden_state
            ensemble_output = (bert_output + roberta_output + xlnet_output + distilbert_output) / 4
        else:
            ensemble_output = (bert_output + roberta_output + distilbert_output) / 3

        return ensemble_output
